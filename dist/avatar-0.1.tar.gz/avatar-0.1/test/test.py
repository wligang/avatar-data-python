#!/usr/bin/env python
# encoding: utf-8
'''
@author: Ligang.Wang
@license: (C) Copyright 2018-2022, wlgdo.com Manager Corporation Limited.
@contact: wlgchun@163.com
@file: test.py
@time: 2019/5/2 1:30
@desc:
'''
print('this is a test')